# Registro Ore 3.3.2 - Linux Mint (64 bit)

## Installazione consigliata (file .deb)

1. Scarica `RegistroOre_3.3.2_LinuxMint_amd64.deb`.
2. Fai doppio clic sul file e scegli **Installa pacchetto** (Gestore pacchetti di Mint/GDebi).
3. L'installazione installa o richiede Java 17+ e Python 3 dalle fonti della tua distribuzione.
4. Apri il menu delle applicazioni, sezione Ufficio/Educazione, e scegli **Registro Ore**.
5. Al primo avvio, con Internet, l'app scarica il driver SQLite JDBC e le piccole librerie SLF4J da Maven Central. Le volte successive funziona offline.

Non e necessario installare VS Code, Maven o SQLite separatamente.

## Alternative: cartella portabile senza privilegi amministrativi

Estrai lo ZIP portabile, apri la cartella `RegistroOre_LinuxMint_Portabile`, poi:
- doppio clic su `AVVIA_REGISTRO_ORE.sh` e scegli **Esegui**;
- oppure avvia il launcher dal terminale: `./AVVIA_REGISTRO_ORE.sh`.

La versione portabile richiede Java 17+ e Python3 gia installati. I dati sono gli stessi che usa l'installazione .deb per lo stesso utente.

## Database vergine e sicurezza dei dati

Il database viene creato **solo se assente** al primo avvio e contiene:
- 0 registrazioni, 0 ore, 0 progetti, 0 colleghi, 0 allegati;
- le 4 categorie predefinite e l'annualita iniziale 2026.

Posizione: `~/.local/share/RegistroOre/data/registro_ore_2026.sqlite`
(o sotto `$XDG_DATA_HOME/RegistroOre` se questa variabile e impostata).

Aggiornamenti del pacchetto .deb sostituiscono esclusivamente i file in `/opt/registro-ore` e NON il database personale. Se si reinstalla la stessa versione, i dati restano invariati. La disinstallazione non cancella il database personale.

Per backup: chiudi Registro Ore, copia tutta la cartella `~/.local/share/RegistroOre/` su un disco sicuro (include gli allegati memorizzati nel database SQLite). Non condividere il database con altri colleghi.

## Comandi per verifiche

- `registro-ore --diagnostica` (verifica presenza database e librerie)
- `registro-ore --inizializza` (crea solo il database senza scaricare librerie)
- `registro-ore` (avvia il programma)

Se si verifica un problema, leggi i log in `~/.local/share/RegistroOre/logs/`. Su Linux Mint l'installazione si esegue tramite GDebi oppure tramite `sudo apt install ./RegistroOre_3.3.2_LinuxMint_amd64.deb` (per la gestione automatica delle dipendenze).

## Requisiti e limitazioni

- Linux Mint 21/22 o distribuzione Ubuntu compatibile, architettura x86-64 (amd64).
- Interfaccia grafica X11 o XWayland e Java Runtime 17 o successivo.
- Al primo avvio serve Internet per i tre file JAR da Maven Central.
- Non firmato digitalmente, non testato direttamente su un PC Linux Mint.
