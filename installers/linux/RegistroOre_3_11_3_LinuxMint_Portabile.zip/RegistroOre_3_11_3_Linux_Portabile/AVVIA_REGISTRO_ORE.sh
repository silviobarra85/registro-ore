#!/usr/bin/env bash
set -e
cd "$(dirname "$(readlink -f "$0")")"
exec ./registro-ore.sh "$@"
