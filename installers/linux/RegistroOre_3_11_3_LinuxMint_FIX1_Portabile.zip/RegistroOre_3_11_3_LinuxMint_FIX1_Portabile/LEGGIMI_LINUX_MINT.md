REGISTRO ORE 3.11.3 — LINUX MINT FIX1

Corregge il controllo errato della libreria slf4j-nop-2.0.17.jar.
Il programma Java resta alla versione 3.11.3. Pacchetto Debian: 3.11.3-2.
Compatibile come aggiornamento con le precedenti installazioni Mint, anche 3.3.2.
L'aggiornamento dalla 3.3.2 comprende le funzioni e le migrazioni della 3.11.3.

METODO CONSIGLIATO: ZIP AGGIORNAMENTO
1. Chiudere Registro Ore.
2. Estrarre completamente lo ZIP AGGIORNAMENTO, ad esempio in Scaricati.
3. Aprire la cartella estratta nel Terminale (clic destro: Apri nel terminale).
4. Eseguire come utente normale, NON anteponendo sudo:

   bash AGGIORNA_REGISTRO_ORE.sh

Lo script crea prima un backup SQLite verificato, poi richiede la password
amministrativa per installare il .deb con apt. Infine prepara le librerie.
Serve Internet per le dipendenze mancanti. Non disinstallare la versione vecchia.
Al termine aprire Registro Ore dal menu di Mint. Verificare il proprio profilo,
le registrazioni e il percorso del database indicato nell'app.

ALTERNATIVA: SOLO FILE .deb
Doppio clic su RegistroOre_3_11_3_LinuxMint_FIX1_amd64.deb e Installa/Aggiorna.
Per un'installazione già usata è preferibile lo ZIP sopra: effettua anche
il backup prima dell'installazione. In alternativa, dal terminale nella cartella:

   sudo apt install ./RegistroOre_3_11_3_LinuxMint_FIX1_amd64.deb
   registro-ore --prepara
   registro-ore

VERSIONE PORTABILE
Estrarre lo ZIP Portabile in una nuova cartella. Aprire lì il Terminale:

   bash AVVIA_REGISTRO_ORE.sh --prepara
   bash AVVIA_REGISTRO_ORE.sh

Richiede Java 17+ e Python 3 già installati. Usa i dati dello stesso utente
come il .deb; non eseguire due copie contemporaneamente. Non sostituire il
database personale con database_vuoto.sqlite presente nella cartella portabile.

DATI
Percorso standard: ~/.local/share/RegistroOre/data/registro_ore_2026.sqlite
Con XDG_DATA_HOME personalizzato: $XDG_DATA_HOME/RegistroOre/data/...
Backup dell'aggiornamento: RegistroOre/backup_aggiornamenti/ accanto a data/.
Lo script non sostituisce né cancella il database esistente o gli allegati.
Le migrazioni della 3.11.3, se necessarie, avvengono all'apertura dell'app
e creano i relativi backup; i valori numerici delle ore vengono conservati.

CONTROLLO
   dpkg-query -W -f='${Version}\n' registro-ore
Risultato atteso del pacchetto: 3.11.3-2 (nell'app compare 3.11.3).
   registro-ore --prepara
Deve terminare con: Componenti pronti.
   registro-ore --diagnostica
I tre componenti devono risultare OK.

Se una vecchia libreria locale viene segnalata non valida, il comando
mostra il suo percorso: conservarne una copia e spostare solo quel file
fuori dalla cartella lib, poi ripetere --prepara. Non cancellare data/.
I log sono in RegistroOre/logs/. Se la rete non è disponibile, il .deb può
risultare installato anche se la preparazione delle librerie non è completata:
riconnettersi e ripetere registro-ore --prepara senza reinstallare il pacchetto.

REQUISITI
Linux Mint/Ubuntu compatibile, amd64, Java 17+, Python 3 e ambiente grafico.
Mac e Windows non richiedono questo aggiornamento.
