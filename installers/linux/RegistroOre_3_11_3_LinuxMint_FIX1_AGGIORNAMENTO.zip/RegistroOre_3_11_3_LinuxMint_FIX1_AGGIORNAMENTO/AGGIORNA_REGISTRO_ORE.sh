#!/bin/sh
set -eu
umask 077
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ "$(id -u)" -eq 0 ]; then
  echo "Esegui questo script come utente normale: bash AGGIORNA_REGISTRO_ORE.sh" >&2
  echo "Lo script richiederà sudo soltanto per installare il pacchetto." >&2
  exit 1
fi
command -v python3 >/dev/null 2>&1 || { echo "Serve Python 3." >&2; exit 1; }
command -v apt >/dev/null 2>&1 || { echo "Serve apt (Linux Mint/Ubuntu)." >&2; exit 1; }
if command -v pgrep >/dev/null 2>&1 && pgrep -u "$(id -u)" -f '(^|/)java([[:space:]]|$).*it[.]registroore[.]App' >/dev/null 2>&1; then
  echo "Chiudi Registro Ore prima di aggiornare, poi ripeti il comando." >&2
  exit 1
fi
ROOT="${XDG_DATA_HOME:-$HOME/.local/share}/RegistroOre"
DB="$ROOT/data/registro_ore_2026.sqlite"
if [ -e "$DB" ]; then
  python3 - "$DB" "$ROOT" <<'PYSQL'
import sqlite3, sys, pathlib, datetime
source=pathlib.Path(sys.argv[1]); root=pathlib.Path(sys.argv[2])
if not source.is_file() or source.stat().st_size == 0:
    raise SystemExit('Database esistente non valido: aggiornamento annullato senza sostituirlo.')
folder=root/'backup_aggiornamenti'; folder.mkdir(parents=True,exist_ok=True)
backup=folder/('prima_3_11_3_Mint_FIX1_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite')
original=sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True)
copy=sqlite3.connect(str(backup))
try:
    if original.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
        raise RuntimeError('Il database originale non supera la verifica di integrità.')
    original.backup(copy)
    if copy.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
        raise RuntimeError('Backup non integro: aggiornamento annullato.')
    print('Backup verificato:',backup)
finally:
    copy.close(); original.close()
PYSQL
else
  echo "Nessun database precedente: verrà inizializzato al primo avvio."
fi
echo "Installazione Registro Ore 3.11.3 Mint FIX1 (pacchetto 3.11.3-2)..."
sudo apt install "$HERE/RegistroOre_3_11_3_LinuxMint_FIX1_amd64.deb"
echo "Pacchetto installato. Preparazione librerie con il tuo utente..."
if registro-ore --prepara; then
  echo "Aggiornamento completato. Apri Registro Ore dal menu di Mint."
else
  echo "Pacchetto installato; preparazione librerie non completata." >&2
  echo "Con Internet disponibile ripeti: registro-ore --prepara" >&2
  exit 1
fi
