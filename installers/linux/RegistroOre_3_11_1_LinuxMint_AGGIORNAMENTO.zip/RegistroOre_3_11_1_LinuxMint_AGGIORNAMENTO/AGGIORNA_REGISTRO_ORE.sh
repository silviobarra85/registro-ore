#!/bin/sh
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ROOT="${XDG_DATA_HOME:-$HOME/.local/share}/RegistroOre"
DB="$ROOT/data/registro_ore_2026.sqlite"
echo "Chiudi Registro Ore prima di aggiornare." 
if [ -f "$DB" ]; then
  python3 - "$DB" "$ROOT" <<'PYSQL'
import sqlite3,sys,pathlib,datetime
source=pathlib.Path(sys.argv[1]);root=pathlib.Path(sys.argv[2]);
folder=root/'backup_aggiornamenti';folder.mkdir(parents=True,exist_ok=True)
backup=folder/('prima_3_11_1_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.sqlite')
original=sqlite3.connect(f'file:{source.resolve()}?mode=ro',uri=True)
copy=sqlite3.connect(str(backup))
try:
    original.backup(copy)
    if copy.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Backup non integro')
    print('Backup verificato:',backup)
finally:
    copy.close();original.close()
PYSQL
else
 echo "Nessun database precedente (prima installazione)."
fi
echo "Installazione pacchetto Registro Ore 3.11.1..."
sudo apt install "$HERE/RegistroOre_3_11_1_LinuxMint_amd64.deb"
echo "Aggiornamento concluso: dati personali conservati."
