#!/bin/bash
# Registro Ore 3.11.3: update only app binaries; NEVER replace a user's database.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/Registro Ore.app"
ROOT="$HOME/Library/Application Support/RegistroOre"
CONFIG="$ROOT/config/db_path.txt"
DEFAULT_DB="$ROOT/data/registro_ore_2026.sqlite"
if [ "$(uname -s)" != Darwin ] && [ "${REGISTRO_TEST_MODE:-0}" != 1 ]; then
 echo "Questo aggiornamento e per macOS"; exit 1
fi
if [ ! -f "$SRC/Contents/Resources/RegistroOre.jar" ]; then
 echo "Pacchetto incompleto: estrai tutto lo ZIP."; exit 1
fi
DB="$DEFAULT_DB"
if [ -s "$CONFIG" ]; then DB="$(cat "$CONFIG")"; fi
if [ ! -f "$DB" ]; then
 echo "Il database configurato non esiste: $DB";
 echo "Aggiornamento annullato. Non viene creato un database vuoto."; exit 1
fi
if command -v lsof >/dev/null 2>&1 && lsof -t "$DB" 2>/dev/null | grep -q .; then
 echo "Chiudi Registro Ore prima di aggiornare."; exit 1
fi
if ! command -v sqlite3 >/dev/null 2>&1; then
 echo "sqlite3 non disponibile: non posso creare un backup sicuro."; exit 1
fi
BKDIR="$(dirname "$DB")/backup_aggiornamenti"
mkdir -p "$BKDIR"
BK="$BKDIR/registro_prima_aggiornamento_$(date +%Y%m%d_%H%M%S)_$$.sqlite"
sqlite3 "$DB" ".backup '$BK'"
if [ ! -s "$BK" ] || [ "$(sqlite3 "$BK" 'PRAGMA integrity_check;' | head -1)" != ok ]; then
 echo "Backup SQLite non valido, aggiornamento annullato."; exit 1
fi
HASH_BEFORE="$(shasum -a 256 "$DB" | cut -d' ' -f1)"
TARGETS=()
[ -d "/Applications/Registro Ore.app" ] && TARGETS+=("/Applications/Registro Ore.app")
[ -d "$HOME/Applications/Registro Ore.app" ] && TARGETS+=("$HOME/Applications/Registro Ore.app")
if [ "${#TARGETS[@]}" -eq 0 ]; then
 mkdir -p "$HOME/Applications"
 TARGETS+=("$HOME/Applications/Registro Ore.app")
fi
for DEST in "${TARGETS[@]}"; do
 if [ "${REGISTRO_TEST_MODE:-0}" = 1 ]; then
  mkdir -p "$DEST";cp -R "$SRC/Contents" "$DEST/"
 elif [ -w "$(dirname "$DEST")" ] && { [ ! -d "$DEST" ] || [ -w "$DEST/Contents/Resources" ]; }; then
  /usr/bin/ditto "$SRC" "$DEST"
 else
  echo "Il sistema potrebbe richiedere la password amministratore per aggiornare: $DEST"
  sudo /usr/bin/ditto "$SRC" "$DEST"
 fi
 chmod +x "$DEST/Contents/MacOS/RegistroOre" 2>/dev/null || true
 echo "Applicazione aggiornata: $DEST"
done
HASH_AFTER="$(shasum -a 256 "$DB" | cut -d' ' -f1)"
if [ "$HASH_BEFORE" != "$HASH_AFTER" ]; then
 echo "ATTENZIONE: database modificato da un altro processo. Backup: $BK";exit 1
fi
echo "Registro Ore 3.11.3 installato. Il database non e stato modificato."
echo "Database attivo: $DB"
echo "Backup pre-aggiornamento: $BK"
echo "Premi INVIO per chiudere."
if [ "${REGISTRO_TEST_MODE:-0}" != 1 ]; then read -r REPLY || true; fi
