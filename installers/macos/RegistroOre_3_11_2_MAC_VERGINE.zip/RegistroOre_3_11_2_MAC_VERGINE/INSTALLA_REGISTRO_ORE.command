#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Applications/Registro Ore.app"
mkdir -p "$HOME/Applications"
if [ -d "$DEST" ]; then echo "Registro Ore e gia installato: usare l'aggiornamento, non l'installazione vergine.";read -r REPLY || true;exit 1;fi
/usr/bin/ditto "$HERE/Registro Ore.app" "$DEST"
chmod +x "$DEST/Contents/MacOS/RegistroOre"
echo "Installato in $DEST. Aprilo dal Finder.";read -r REPLY || true
