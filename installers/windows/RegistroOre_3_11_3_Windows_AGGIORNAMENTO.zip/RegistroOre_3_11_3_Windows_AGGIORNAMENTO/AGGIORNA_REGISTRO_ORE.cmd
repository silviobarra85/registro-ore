@echo off
setlocal
chcp 65001 >nul
set "REGISTRO_ROOT=%LOCALAPPDATA%\RegistroOre"
echo Registro Ore 3.11.3 - Aggiornamento Windows
echo Chiudi Registro Ore prima di continuare.
pause
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $root=Join-Path $env:LOCALAPPDATA 'RegistroOre'; $db=Join-Path $root 'data\registro_ore_2026.sqlite'; if(Test-Path -LiteralPath $db){ $stamp=Get-Date -Format 'yyyyMMdd_HHmmss'; $folder=Join-Path $root ('backup_aggiornamenti\prima_3_11_3_'+$stamp); New-Item -ItemType Directory -Path $folder -Force | Out-Null; Copy-Item -LiteralPath $db -Destination (Join-Path $folder 'registro_ore_2026.sqlite') -ErrorAction Stop; foreach($extension in @('-wal','-shm')){if(Test-Path -LiteralPath ($db+$extension)){Copy-Item -LiteralPath ($db+$extension) -Destination (Join-Path $folder ('registro_ore_2026.sqlite'+$extension)) -ErrorAction Stop}}; Write-Host ('Backup creato: '+$folder) } else {Write-Host 'Nessun database precedente: prima installazione'}"
if errorlevel 1 (
 echo ERRORE: backup non riuscito, aggiornamento annullato.
 pause
 exit /b 1
)
echo Avvio Registro Ore 3.11.3: il database personale sara' conservato.
start "Registro Ore" "%~dp0RegistroOre.exe"
